package com.nico.pagantis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PagantisApplication {

	public static void main(String[] args) {
		SpringApplication.run(PagantisApplication.class, args);
	}

}
